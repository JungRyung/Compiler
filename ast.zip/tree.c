#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

void printtree(Tree root) {
    printf("Merong!\n");
}

Tree mkleaf(NKind kind, int val) {
    Tree t = (Tree)malloc(sizeof *t);
    t->kind = kind;
    t->ival = val;
    t->bro = t->son = NULL;
    return t;
}

Tree mknode(NKind kind, int val, Tree bro, Tree son) {
    Tree t = (Tree)malloc(sizeof *t);
    t->kind = kind;
    t->ival = val;
    t->bro = bro;
    t->son = son;
    return t;
}
